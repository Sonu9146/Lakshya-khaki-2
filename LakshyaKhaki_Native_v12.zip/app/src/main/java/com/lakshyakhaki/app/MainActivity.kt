
package com.lakshyakhaki.app

import android.Manifest
import android.app.*
import android.app.TimePickerDialog
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import androidx.navigation.compose.*
import com.lakshyakhaki.app.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private val Context.lakshyaDataStore by preferencesDataStore("lakshya_settings")
private val DAILY_MCQ_GOAL = intPreferencesKey("daily_mcq_goal")
private val DAILY_GROUND_GOAL = booleanPreferencesKey("daily_ground_goal")
private val REMINDER_ENABLED = booleanPreferencesKey("reminder_enabled")
private val REMINDER_HOUR = intPreferencesKey("reminder_hour")
private val REMINDER_MINUTE = intPreferencesKey("reminder_minute")

private const val REMINDER_CHANNEL = "lakshya_reminders"
private const val REMINDER_REQUEST = 4101

private val db by lazy { AppDatabase.get(App.instance) }

class App : android.app.Application() {
    companion object { lateinit var instance: App }
    override fun onCreate() { super.onCreate(); instance = this }
}

private fun scheduleDailyReminder(context: Context, hour: Int, minute: Int) {
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, ReminderReceiver::class.java)
    val pending = PendingIntent.getBroadcast(
        context, REMINDER_REQUEST, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val cal = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
    }
    alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pending)
}

private fun cancelDailyReminder(context: Context) {
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, ReminderReceiver::class.java)
    val pending = PendingIntent.getBroadcast(
        context, REMINDER_REQUEST, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    alarm.cancel(pending)
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(
                REMINDER_CHANNEL, "Lakshya Khaki Reminders", NotificationManager.IMPORTANCE_DEFAULT
            ))
        }
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(context, REMINDER_CHANNEL)
        else Notification.Builder(context)
        manager.notify(
            REMINDER_REQUEST,
            n.setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("लक्ष्य खाकी")
                .setContentText("आजची MCQ practice आणि Ground training check करा.")
                .setAutoCancel(true).build()
        )
    }
}

data class StudyTopic(val title: String, val subtitle: String, val bullets: List<String>)
data class Question(val category: String, val question: String, val options: List<String>, val answer: Int)

private val studyTopics = listOf(
    StudyTopic("मराठी व्याकरण","संधी • समास • शब्दशक्ती • वाक्यरचना",
        listOf("संधीचे प्रकार आणि उदाहरणे","समासाचे प्रमुख प्रकार","शब्दांचे अर्थ व विरुद्धार्थी","वाक्यशुद्धी सराव")),
    StudyTopic("गणित","टक्केवारी • सरासरी • गुणोत्तर • संख्या",
        listOf("टक्केवारीची मूलभूत सूत्रे","सरासरी व गुणोत्तर","नफा-तोटा व साधे व्याज","संख्या मालिका सराव")),
    StudyTopic("GK / GS","महाराष्ट्र • भारत • सामान्य विज्ञान",
        listOf("महाराष्ट्र सामान्यज्ञान","भारतीय राज्यघटना basics","दैनंदिन विज्ञान","महत्त्वाचे दिवस व तथ्ये")),
    StudyTopic("Reasoning","Series • Coding • Ranking • Analogy",
        listOf("अक्षर व संख्या मालिका","Coding-Decoding","क्रमांक व दिशा","साम्य व वर्गीकरण"))
)

private val questions = listOf(
    Question("मराठी","‘रामाने आंबा खाल्ला.’ या वाक्यातील कर्ता कोणता?",listOf("रामाने","आंबा","खाल्ला","या"),0),
    Question("मराठी","‘सुंदर’ या शब्दाचा विरुद्धार्थी शब्द कोणता?",listOf("कुरूप","मोठा","गोड","लहान"),0),
    Question("मराठी","‘राजपुत्र’ हा कोणत्या समासाचा प्रकार आहे?",listOf("द्वंद्व","तत्पुरुष","बहुव्रीही","अव्ययीभाव"),1),
    Question("मराठी","‘मी शाळेत जातो.’ या वाक्यातील क्रियापद कोणते?",listOf("मी","शाळेत","जातो","या"),2),
    Question("गणित","25% of 240 किती?",listOf("40","50","60","80"),2),
    Question("गणित","15 × 8 − 20 = ?",listOf("90","100","110","120"),1),
    Question("गणित","एका संख्येचा 3/5 भाग 36 आहे. संख्या किती?",listOf("48","60","72","90"),1),
    Question("गणित","2, 6, 12, 20, 30, ? पुढील संख्या कोणती?",listOf("40","42","44","46"),1),
    Question("GK/GS","महाराष्ट्राची राजधानी कोणती?",listOf("मुंबई","पुणे","नागपूर","नाशिक"),0),
    Question("GK/GS","भारताचा राष्ट्रीय प्राणी कोणता?",listOf("सिंह","वाघ","हत्ती","मोर"),1),
    Question("GK/GS","पाण्याचे रासायनिक सूत्र कोणते?",listOf("CO₂","O₂","H₂O","NaCl"),2),
    Question("GK/GS","भारतीय संविधानाचा स्वीकार कोणत्या दिवशी झाला?",listOf("15 ऑगस्ट 1947","26 नोव्हेंबर 1949","26 जानेवारी 1950","2 ऑक्टोबर 1950"),1),
    Question("Reasoning","A, C, E, G, ? पुढील अक्षर कोणते?",listOf("H","I","J","K"),1),
    Question("Reasoning","3, 9, 27, 81, ? पुढील संख्या कोणती?",listOf("162","216","243","324"),2),
    Question("Reasoning","जर CAT = DBU असेल, तर DOG = ?",listOf("EPH","EOG","DPH","FPI"),0),
    Question("Reasoning","एका रांगेत राहुल डावीकडून 8वा आणि उजवीकडून 13वा आहे. एकूण किती जण?",listOf("19","20","21","22"),1)
)

data class MockTest(val title: String, val subtitle: String, val category: String, val count: Int)

private val mockTests = listOf(
    MockTest("Marathi Grammar Mock", "व्याकरणावर timed test", "मराठी", 4),
    MockTest("Maths Mock", "गणिताचा जलद सराव", "गणित", 4),
    MockTest("GK / GS Mock", "सामान्यज्ञान + विज्ञान", "GK/GS", 4),
    MockTest("Reasoning Mock", "तर्कशक्तीचा सराव", "Reasoning", 4),
    MockTest("Full Syllabus Mock", "सर्व विषयांचा mixed test", "All", 16)
)

private fun parseTimeSeconds(v: String): Double? {
    val t=v.trim()
    if (t.contains(":")) {
        val p=t.split(":"); if (p.size==2) return (p[0].toDoubleOrNull() ?: return null)*60+(p[1].toDoubleOrNull() ?: return null)
    }
    return t.toDoubleOrNull()
}
private fun formatTime(s: Double) = if (s >= 60) "${(s/60).toInt()}:${String.format(Locale.getDefault(),"%04.1f",s%60)}"
else String.format(Locale.getDefault(),"%.1f sec",s)

private fun dateKey(ts: Long) = SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date(ts))
private fun todayCount(ts: Long) = ts.map(::dateKey).count { it == dateKey(System.currentTimeMillis()) }

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            LakshyaKhakiApp(
                requestNotificationPermission = {
                    if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            )
        }
    }
}

@Composable
fun LakshyaKhakiApp(requestNotificationPermission: () -> Unit) {
    val nav=rememberNavController()
    val colors = darkColorScheme(
        primary=Color(0xFF5EA7FF),
        secondary=Color(0xFF8CBFFF),
        background=Color(0xFF07111F),
        surface=Color(0xFF0D1A2B),
        surfaceVariant=Color(0xFF15253A)
    )
    MaterialTheme(colorScheme=colors) {
        Scaffold(
            containerColor=colors.background,
            bottomBar={
                NavigationBar(containerColor=Color(0xFF0A1626)) {
                    listOf("home" to "Home","study" to "Study","ground" to "Ground","progress" to "Progress","profile" to "Profile").forEach { (route,label) ->
                        val current=nav.currentBackStackEntryAsState().value?.destination?.route
                        NavigationBarItem(
                            selected=current==route,
                            onClick={ nav.navigate(route) { launchSingleTop=true; popUpTo("home") { saveState=true } } },
                            icon={Text(if(route=="home") "⌂" else if(route=="study") "📚" else if(route=="ground") "🏃" else if(route=="progress") "📈" else "👤")},
                            label={Text(label)}
                        )
                    }
                }
            }
        ) { p ->
            NavHost(nav,"home",Modifier.padding(p)) {
                composable("home"){Home(nav)}
                composable("study"){Study(onQuiz={cat->nav.navigate("quiz/${cat.replace("/","_")}")}, onMocks={nav.navigate("mocks")})}
                composable("mocks"){MockTests{cat->nav.navigate("quiz/${cat.replace("/","_")}")}}
                composable("quiz/{category}") { back ->
                    val cat=back.arguments?.getString("category")?.replace("_","/") ?: "All"
                    Quiz(cat){nav.popBackStack()}
                }
                composable("ground"){Ground()}
                composable("progress"){Progress()}
                composable("profile"){Profile(nav,requestNotificationPermission)}
                composable("daily"){DailyGoals()}
                composable("reminders"){ReminderSettings(requestNotificationPermission)}
            }
        }
    }
}

@Composable
fun Home(nav: NavHostController) {
    val scope=rememberCoroutineScope()
    val context=LocalContext.current
    var goal by remember { mutableStateOf(20) }
    var groundGoal by remember { mutableStateOf(false) }
    var quizToday by remember { mutableStateOf(0) }
    var groundToday by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        val p=context.lakshyaDataStore.data.first()
        goal=p[DAILY_MCQ_GOAL]?:20; groundGoal=p[DAILY_GROUND_GOAL]?:false
        quizToday=todayCount(db.quizDao().all().first().map{it.timestamp})
        groundToday=todayCount(db.groundDao().all().first().map{it.timestamp})
    }
    val mcqProgress=(quizToday*10).coerceAtMost(goal)
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("लक्ष्य खाकी",style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Bold)
        Text("तुमचे लक्ष्य, आमचे मार्गदर्शन.",style=MaterialTheme.typography.titleMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)
        Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("आजची Progress",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                Text("🧠 MCQ: $mcqProgress / $goal")
                LinearProgressIndicator(progress={(mcqProgress.toFloat()/goal.coerceAtLeast(1))},modifier=Modifier.fillMaxWidth())
                Text("🏃 Ground: "+if(groundGoal && groundToday>0)"Complete ✓" else if(groundGoal)"Pending" else "Not planned")
            }
        }
        Button({nav.navigate("quiz/All")},Modifier.fillMaxWidth()){Text("⚡ Quick MCQ सुरू करा")}
        OutlinedButton({nav.navigate("study")},Modifier.fillMaxWidth()){Text("📚 अभ्यास उघडा")}
        OutlinedButton({nav.navigate("ground")},Modifier.fillMaxWidth()){Text("🏃 Ground Tracker")}
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Weekly focus",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                Text("1600m • 100m • Shot Put • रोज timed MCQ practice",color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun Study(onQuiz:(String)->Unit, onMocks:()->Unit) {
    var selected by remember{mutableStateOf<StudyTopic?>(null)}
    if(selected==null) Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("अभ्यास",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text("रोज थोडं, सातत्याने मोठी तयारी.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onMocks,Modifier.fillMaxWidth()){Text("📝 Mock Tests")}
        studyTopics.forEach{topic->Card(Modifier.fillMaxWidth().clickable{selected=topic}){
            Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Text(topic.title,style=MaterialTheme.typography.titleLarge);Text(topic.subtitle,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("${topic.bullets.size} मुख्य topics",style=MaterialTheme.typography.labelMedium)}
        }}
    } else {
        val topic=selected!!
        Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            TextButton({selected=null}){Text("← अभ्यासाकडे")}
            Text(topic.title,style=MaterialTheme.typography.headlineSmall)
            topic.bullets.forEachIndexed{i,b->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(15.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){Text("${i+1}.");Text(b)}}}
            Button({onQuiz(topic.title)},Modifier.fillMaxWidth()){Text("या विषयाचा MCQ सराव")}
        }
    }
}

@Composable
fun MockTests(onStart:(String)->Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("Mock Tests",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text("Police Bharti pattern साठी timed practice.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        mockTests.forEach { test ->
            Card(Modifier.fillMaxWidth().clickable{onStart(test.category)}) {
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                    Text(test.title,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                    Text(test.subtitle,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${test.count} questions • 30 sec/question",style=MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
fun Quiz(category:String,onDone:()->Unit) {
    val filtered=remember(category){if(category=="All")questions else questions.filter{it.category==category}.ifEmpty{questions}}
    var index by remember{mutableStateOf(0)}
    var answers by remember{mutableStateOf(List(filtered.size){-1})}
    var seconds by remember{mutableStateOf(filtered.size*30)}
    var finished by remember{mutableStateOf(false)}
    LaunchedEffect(finished){while(!finished&&seconds>0){delay(1000);seconds--};if(!finished&&seconds==0)finished=true}
    if(finished){
        val score=answers.indices.count{answers[it]==filtered[it].answer}
        val attempted=answers.count{it>=0}
        LaunchedEffect(Unit){db.quizDao().insert(QuizResult(category,score,filtered.size))}
        Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
            Text("Quiz Result",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
            Text("$score / ${filtered.size}",style=MaterialTheme.typography.displaySmall)
            Text("${if(filtered.isEmpty())0 else score*100/filtered.size}% • Attempted $attempted/${filtered.size}")
            Button({onDone()},Modifier.fillMaxWidth()){Text("Back")}
        }
        return
    }
    val q=filtered[index]
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Question ${index+1}/${filtered.size}");Text(String.format(Locale.getDefault(),"%02d:%02d",seconds/60,seconds%60))}
        LinearProgressIndicator(progress={(index+1f)/filtered.size},modifier=Modifier.fillMaxWidth())
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
            Text(q.category,style=MaterialTheme.typography.labelLarge)
            Text(q.question,style=MaterialTheme.typography.titleLarge)
            q.options.forEachIndexed{i,opt->OutlinedButton({answers=answers.toMutableList().also{it[index]=i}},Modifier.fillMaxWidth()){Text("${('A'.code+i).toChar()}. $opt"+if(answers[index]==i)" ✓" else "")}}
        }}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton({if(index>0)index--},enabled=index>0,modifier=Modifier.weight(1f)){Text("Previous")}
            Button({if(index<filtered.lastIndex)index++ else finished=true},Modifier.weight(1f)){Text(if(index==filtered.lastIndex)"Finish" else "Next")}
        }
    }
}

@Composable
fun Ground() {
    val scope=rememberCoroutineScope()
    var event by remember{mutableStateOf("1600m")}
    var value by remember{mutableStateOf("")}
    var history by remember{mutableStateOf(listOf<GroundResult>())}
    LaunchedEffect(Unit){history=db.groundDao().all().first()}
    val rows=history.filter{it.event==event}
    val best=if(event=="Shot Put") rows.mapNotNull{it.value.toDoubleOrNull()}.maxOrNull()?.let{"%.2f m".format(it)}
    else rows.mapNotNull{parseTimeSeconds(it.value)}.minOrNull()?.let(::formatTime)
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Ground Tracker",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(7.dp)){listOf("1600m","100m","Shot Put").forEach{e->FilterChip(event==e,{event=e;value=""},{Text(e)})}}
        OutlinedTextField(value,{value=it.filter{c->c.isDigit()||c=='.'||c==':'}} ,label={Text(if(event=="Shot Put")"Distance (m)" else "Time (sec)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        Button({if(value.isNotBlank())scope.launch{db.groundDao().insert(GroundResult(event=event,value=value));value="";history=db.groundDao().all().first()}},enabled=value.isNotBlank(),modifier=Modifier.fillMaxWidth()){Text("Save Performance")}
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Personal Best",style=MaterialTheme.typography.titleMedium);Text(best?:"No record yet",style=MaterialTheme.typography.headlineSmall);Text("${rows.size} saved attempt(s)",color=MaterialTheme.colorScheme.onSurfaceVariant)}}
        Text("Recent History",style=MaterialTheme.typography.titleLarge)
        LazyColumn{items(rows.take(8)){r->ListItem({Text(r.value+(if(event=="Shot Put")" m" else " sec"))},{Text(SimpleDateFormat("dd MMM, HH:mm",Locale.getDefault()).format(Date(r.timestamp)))})}}
    }
}

@Composable
fun Progress() {
    val ground=remember{mutableStateListOf<GroundResult>()}
    val quizzes=remember{mutableStateListOf<QuizResult>()}
    LaunchedEffect(Unit){ground.addAll(db.groundDao().all().first());quizzes.addAll(db.quizDao().all().first())}
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Progress",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        listOf("1600m","100m","Shot Put").forEach{event->
            val rows=ground.filter{it.event==event};val vals=rows.mapNotNull{if(event=="Shot Put")it.value.toDoubleOrNull() else parseTimeSeconds(it.value)}
            val best=if(event=="Shot Put")vals.maxOrNull() else vals.minOrNull()
            Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                Text(event,style=MaterialTheme.typography.titleLarge);Text("Personal Best: "+(if(best==null)"—" else if(event=="Shot Put")"%.2f m".format(best) else formatTime(best)));Text("${rows.size} attempts",color=MaterialTheme.colorScheme.onSurfaceVariant)
            }}
        }
        val total=quizzes.sumOf{it.total};val score=quizzes.sumOf{it.score};val pct=if(total>0)score*100/total else 0
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){Text("Study Performance",style=MaterialTheme.typography.titleLarge);Text("${quizzes.size} quiz attempts");Text("Overall MCQ accuracy: $pct%");LinearProgressIndicator(progress={pct/100f},modifier=Modifier.fillMaxWidth())}}
    }
}

private fun calculateStreak(ts:List<Long>):Int{
    val set=ts.map(::dateKey).toSet();var d=Calendar.getInstance();var streak=0
    while(set.contains(SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(d.time))){streak++;d.add(Calendar.DAY_OF_YEAR,-1)}
    return streak
}

@Composable
fun Profile(nav:NavHostController,requestPermission:()->Unit){
    val scope=rememberCoroutineScope();val context=LocalContext.current
    var ground by remember{mutableStateOf(listOf<GroundResult>())};var quizzes by remember{mutableStateOf(listOf<QuizResult>())}
    LaunchedEffect(Unit){ground=db.groundDao().all().first();quizzes=db.quizDao().all().first()}
    val streak=calculateStreak(ground.map{it.timestamp}+quizzes.map{it.timestamp})
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Profile",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("Current Streak",style=MaterialTheme.typography.titleMedium);Text("$streak day 🔥",style=MaterialTheme.typography.headlineSmall);Text("Quiz: ${quizzes.size} • Ground: ${ground.size}",color=MaterialTheme.colorScheme.onSurfaceVariant)}}
        Button({nav.navigate("daily")},Modifier.fillMaxWidth()){Text("🎯 Daily Goals")}
        OutlinedButton({nav.navigate("reminders")},Modifier.fillMaxWidth()){Text("🔔 Reminder Settings")}
        Text("Achievements",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
        val bestQuiz=quizzes.maxOfOrNull{if(it.total>0)it.score*100/it.total else 0}?:0
        listOf(
            "🎯 First Step" to (quizzes.isNotEmpty()),"🧠 Quiz Starter" to (quizzes.size>=5),
            "🏃 Ground Ready" to (ground.isNotEmpty()),"🔥 Training Mode" to (ground.size>=10),
            "🏆 80% Club" to (bestQuiz>=80),"⚡ 3 Day Streak" to (streak>=3),"👑 7 Day Streak" to (streak>=7)
        ).forEach{(name,ok)->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=if(ok)MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)){Text(name+(if(ok)" ✓" else " 🔒"),Modifier.padding(14.dp))}}
    }
}

@Composable
fun DailyGoals(){
    val context=LocalContext.current;val scope=rememberCoroutineScope()
    var mcq by remember{mutableStateOf(20)};var ground by remember{mutableStateOf(false)};var saved by remember{mutableStateOf(false)}
    LaunchedEffect(Unit){val p=context.lakshyaDataStore.data.first();mcq=p[DAILY_MCQ_GOAL]?:20;ground=p[DAILY_GROUND_GOAL]?:false}
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Daily Goals",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("MCQ Goal",style=MaterialTheme.typography.titleLarge);Text("$mcq questions/day");Slider({mcq=it.toInt()},mcq.toFloat(),5f..100f,steps=18)}}
        Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Ground Training",style=MaterialTheme.typography.titleLarge);Text("आज training planned?",color=MaterialTheme.colorScheme.onSurfaceVariant)};Switch(ground,{ground=it})}}
        Button({scope.launch{context.lakshyaDataStore.edit{it[DAILY_MCQ_GOAL]=mcq;it[DAILY_GROUND_GOAL]=ground};saved=true}},Modifier.fillMaxWidth()){Text(if(saved)"Saved ✓" else "Save Daily Goals")}
    }
}

@Composable
fun ReminderSettings(requestPermission:()->Unit){
    val context=LocalContext.current;val scope=rememberCoroutineScope()
    var enabled by remember{mutableStateOf(true)};var hour by remember{mutableStateOf(19)};var minute by remember{mutableStateOf(0)}
    LaunchedEffect(Unit){val p=context.lakshyaDataStore.data.first();enabled=p[REMINDER_ENABLED]?:false;hour=p[REMINDER_HOUR]?:19;minute=p[REMINDER_MINUTE]?:0}
    fun persist(){scope.launch{context.lakshyaDataStore.edit{it[REMINDER_ENABLED]=enabled;it[REMINDER_HOUR]=hour;it[REMINDER_MINUTE]=minute}}}
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Reminders",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Daily Reminder",style=MaterialTheme.typography.titleLarge);Text(String.format(Locale.getDefault(),"%02d:%02d",hour,minute))};Switch(enabled,{enabled=it;if(it){scheduleDailyReminder(context,hour,minute);requestPermission()}else cancelDailyReminder(context);persist()})}}
        OutlinedButton({
            TimePickerDialog(context, { _, h, m ->
                hour=h; minute=m
                if(enabled) scheduleDailyReminder(context,hour,minute)
                persist()
            }, hour, minute, true).show()
        },Modifier.fillMaxWidth()){Text("🕒 Change reminder time")}
        Text("Default: 7:00 PM • Android may deliver slightly later to save battery.",color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
