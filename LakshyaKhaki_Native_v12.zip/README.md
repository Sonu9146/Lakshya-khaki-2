# Lakshya Khaki Native v2

This version moves the core experience toward a real native Android app:
- Jetpack Compose UI (no WebView)
- Native bottom navigation
- Native MCQ engine with scoring
- Room database for quiz and ground results
- Native Ground Tracker
- Native Progress screen reading saved quiz data

The original HTML source is preserved under `source/` for the remaining content migration.


## v11
Open the folder in Android Studio, sync Gradle, then Build > Build APK(s). The app is native Jetpack Compose; it does not use WebView.
